#include <iostream>
#include "pointdis.h"

using namespace geo_distance;
int main() {
    Point pt(150,250);
    Line line;
    line.p0 = Point(100, 200);
    line.p1 = Point(150, 300);

    PLDistance pl;
    float dis = pl.dist_Point_to_Line(pt,line);

    std::cout << "return," <<dis<< std::endl;  
    std::cin.ignore();
}
